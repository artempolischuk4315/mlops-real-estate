import boto3
import os
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
sm = boto3.client("sagemaker")
PIPELINE_NAME = os.environ["PIPELINE_NAME"]
def lambda_handler(event, context):
    logger.info(f"Event: {event}")
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    input_data_uri = f"s3://{bucket}/{key}"
    response = sm.start_pipeline_execution(
        PipelineName=PIPELINE_NAME,
        PipelineExecutionDisplayName=f"Triggered-by-S3-Upload",
        PipelineParameters=[{'Name': 'InputData', 'Value': input_data_uri}]
    )
    return {"status": "started", "arn": response["PipelineExecutionArn"]}
