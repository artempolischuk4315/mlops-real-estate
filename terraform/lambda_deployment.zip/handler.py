import boto3
import time
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sm = boto3.client("sagemaker")


def lambda_handler(event, context):
    """
    Ця лямбда викликається кроком SageMaker Pipeline.
    Вона отримує ARN зареєстрованої моделі і оновлює ендпоінт.
    """
    logger.info(f"Received event: {event}")

    # Отримуємо параметри, які передав Pipeline (див. generate_pipeline_definition.py)
    # Якщо ти використовуєш код генерації, який я давав, то ключі такі:
    model_package_arn = event.get("model_package_arn")
    endpoint_name = event.get("endpoint_name")
    role_arn = event.get("role_arn")

    # Якщо раптом параметри прийшли інакше (залежить від твого python скрипта генерації),
    # то fallback на твій старий варіант:
    if not model_package_arn and 'model_url' in event:
        # Це означає, що пайплайн передав прямі посилання, а не Package ARN
        # Але краще використовувати Package ARN.
        logger.warning("Using raw model_url instead of ModelPackage (Legacy mode)")
        return legacy_deploy_mode(event)

    if not model_package_arn or not endpoint_name:
        raise ValueError(f"Missing required parameters. Got: {event}")

    timestamp = int(time.time())
    model_name = f"pipeline-model-{timestamp}"
    config_name = f"pipeline-config-{timestamp}"

    # 1. Створюємо об'єкт Model в SageMaker
    # Ми використовуємо "ModelPackageName", це посилання на Model Registry.
    # Це набагато надійніше, ніж передавати s3 url руками.
    logger.info(f"Creating Model: {model_name} from Package: {model_package_arn}")

    sm.create_model(
        ModelName=model_name,
        PrimaryContainer={
            "ModelPackageName": model_package_arn
        },
        ExecutionRoleArn=role_arn
    )

    # 2. Створюємо конфіг ендпоінта
    logger.info(f"Creating EndpointConfig: {config_name}")
    sm.create_endpoint_config(
        EndpointConfigName=config_name,
        ProductionVariants=[{
            "VariantName": "AllTraffic",
            "ModelName": model_name,
            "InitialInstanceCount": 1,
            "InstanceType": "ml.m5.large"
        }]
    )

    # 3. Оновлюємо або створюємо ендпоінт
    try:
        logger.info(f"Updating endpoint: {endpoint_name}")
        sm.update_endpoint(
            EndpointName=endpoint_name,
            EndpointConfigName=config_name
        )
        return {"status": "updating", "endpoint": endpoint_name}
    except sm.exceptions.ClientError:
        logger.info(f"Endpoint not found, creating new: {endpoint_name}")
        sm.create_endpoint(
            EndpointName=endpoint_name,
            EndpointConfigName=config_name
        )
        return {"status": "creating", "endpoint": endpoint_name}


def legacy_deploy_mode(event):
    # Це резервний варіант, якщо ти не хочеш міняти generate_pipeline_definition.py
    # Але тут ми прибрали MLflow
    timestamp = int(time.time())
    model_name = f"real-estate-model-{timestamp}"

    sm.create_model(
        ModelName=model_name,
        PrimaryContainer={
            'Image': event['image_uri'],
            'ModelDataUrl': event['model_url'],
            'Environment': {
                'SAGEMAKER_PROGRAM': 'inference.py',
                'SAGEMAKER_SUBMIT_DIRECTORY': event['model_url']
            }
        },
        ExecutionRoleArn=os.environ.get('EXECUTION_ROLE_ARN', event.get('role_arn'))
    )

    config_name = f"real-estate-config-{timestamp}"
    sm.create_endpoint_config(
        EndpointConfigName=config_name,
        ProductionVariants=[{
            'VariantName': 'AllTraffic',
            'ModelName': model_name,
            'InitialInstanceCount': 1,
            'InstanceType': 'ml.m5.large'
        }]
    )

    endpoint_name = os.environ.get("ENDPOINT_NAME", event.get("endpoint_name"))

    try:
        sm.update_endpoint(EndpointName=endpoint_name, EndpointConfigName=config_name)
    except:
        sm.create_endpoint(EndpointName=endpoint_name, EndpointConfigName=config_name)

    return {"status": "deployed (legacy)"}